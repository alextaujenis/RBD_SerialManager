#Arduino Serial Manager Library v1.0.0-alpha.1
A simple interface for serial communication.

* [Documentation](http://robotsbigdata.com/docs-arduino-serial-manager.html)
* [Download Library](https://github.com/alextaujenis/RBD_SerialManager/raw/master/extras/RBD_SerialManager.zip)
* [Project Website](http://robotsbigdata.com)
* [Report an Issue](https://github.com/alextaujenis/RBD_SerialManager/issues/new)*

\**Please include your Arduino make/model and IDE version when reporting an issue with this library.*

#License
This code is available under the [MIT License](http://opensource.org/licenses/mit-license.php).